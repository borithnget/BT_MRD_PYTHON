from django.urls import path
from . import views

#app_name = 'mdrapp'

urlpatterns = [
    path('index/<int:id>', views.index, name='index'),
    path('create/<int:id>', views.create_watersupply, name= 'watersupply_create'),
    path('detail/<int:id>', views.detail, name= 'watersupply_detail'),
    path('edit/<int:id>', views.edit, name="watersupply_edit"),
    path('myreqeust/', views.watersupply_myreqeust, name='watersupply_myrequest'),
    path('myapproval/', views.watersupply_myapproval, name="watersupply_myapproval"),
    path('myapprovalhistory/', views.watersupply_myapprovalhistory, name="watersupply_myapprovalhistory"),
    path('userlist/', views.user_index, name='user_index'),
    path('register/', views.user_register, name='user_register'),
    path('qrcode/', views.qr_gen, name='qr_gen'),
    path('reportwatersupplymap/', views.report_water_supply_map, name='report_watersupply_map'),
]
