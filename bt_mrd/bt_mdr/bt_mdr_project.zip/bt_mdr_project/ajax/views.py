from pickle import NONE
from urllib import request
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import requests
# Create your views here.

MAIN_URL = 'http://127.0.0.1:8000/api/' 

def get_province_list(request):
    if request.method == "GET":
        province_api_url = MAIN_URL + "province/"
        provinces = requests.get(province_api_url).json()
        return JsonResponse({"provinces":provinces}, status=200)
    return JsonResponse({}, status = 400)

def district(request):
    if request.method == "GET":
        province_id = request.GET.get('province_id', NONE)
        district_url = MAIN_URL + 'district/?search=' + str(province_id)
        districts = requests.get(district_url).json()
        return JsonResponse({"district" : districts}, status=200)
    return JsonResponse({}, status = 400)

def get_commnue_list(request):
    if request.method == "GET":
        district_id = request.GET.get('district_id', NONE)
        commune_url = MAIN_URL + 'commune/?search=' + str(district_id)
        commnues = requests.get(commune_url).json()
        return JsonResponse({'communes': commnues}, status = 200)
    return JsonResponse({}, status = 400)

def get_village_list(request):
    if request.method == "GET":
        commune_id = request.GET.get('commune_id', NONE)
        village_url = MAIN_URL + 'village/?search=' + str(commune_id)
        villages = requests.get(village_url).json()
        return JsonResponse({'villages':villages}, status=200)
    return JsonResponse({}, status=400)

def get_watersupply_list(request):
    if request.method == "GET":
        water_supply_url = MAIN_URL + 'watersupply/?water_supply_type_id=&main_status=9'
        watersupplylist = requests.get(water_supply_url).json()
        return JsonResponse({'data':watersupplylist}, status=200)
    return JsonResponse({}, status = 400)

def get_myrequest_draft_list(request):
    if request.method == "GET":
        user_id = request.user.id
        url = MAIN_URL + 'watersupplybyuserandstatus/?created_by='+ str(user_id) +'&main_status=3'
        list= requests.get(url).json()
        return JsonResponse({'data':list}, status=200)
    return JsonResponse({}, status = 400)

def get_myrequest_history_list(request):
    if request.method == "GET":     
        user_id = request.user.id
        url = MAIN_URL + "watersupplybyuser/?search="+str(user_id)
        list= requests.get(url).json()
        return JsonResponse({'data':list}, status=200)
    return JsonResponse({}, status=400)


#START POST SECTION
def post_approval_watersupply_by_provicial_head_department(request):
    if request.method == "GET":
        headers = {'Content-Type': 'application/json'}
        water_supply_id = request.GET.get('water_supply_id', NONE)
        status_id = request.GET.get('status_id',NONE)
        remark = request.GET.get('remark',NONE)

        #print(water_supply_id + " " + status_id)
        ws_workflow = "http://127.0.0.1:8000/en/api/v2/watersupplyworkflow"
        payload_wsworkflow = {
            "watersupply_id": water_supply_id,
            "status_id":int(status_id),
            "user_id": int(request.user.id),
            "remark": remark
        }
        #print(payload_wsworkflow)
        response_ws_workflow = requests.post(ws_workflow, json=payload_wsworkflow, headers=headers).json()

        #Update Water Supply MainStatus
        ws_update_url = "http://127.0.0.1:8000/en/api/watersupply/"+ str (water_supply_id) +"/update/"
        ws_update_payload = {
            "id": water_supply_id,
            "main_status": status_id
        }
        response_ws_upate_mainstatus = requests.put(ws_update_url, json=ws_update_payload, headers=headers).json()
        #print(response_ws_upate_mainstatus)

        return JsonResponse({'is_success':True},status=200)
    return JsonResponse({}, status=400)

def put_water_supply_delete(request):
    if request.method == "GET":
        headers = {'Content-Type': 'application/json'}
        water_supply_id = request.GET.get('water_supply_id', NONE)

        ws_delete_url = "http://127.0.0.1:8000/en/api/v2/watersupply/" + str(water_supply_id) + "/delete/"
        ws_delete_payload = {
            "id": water_supply_id,
            "updated_by": int(request.user.id),
            "is_active": False
        }
        response_delete_ws = requests.put(ws_delete_url, json=ws_delete_payload, headers=headers).json()
        return JsonResponse({'is_success':True},status=200)
    return JsonResponse({}, status=400)

#END POST SECTION

