from django.shortcuts import render, redirect
import googlemaps
import json
from django.conf import settings
from django.http import HttpResponse
import requests
import json
from rest_framework.parsers import JSONParser
import datetime, time
from qrcode import *
from django.conf import settings
# Create your views here.

MAIN_URL = 'http://127.0.0.1:8000/api/' 
MAIN_URL_1 = 'http://127.0.0.1:8000/en/'

def geocode(request):
    gmaps = googlemaps.Client(key= settings.GOOGLE_API_KEY)
    result = gmaps.geocode(str('Stadionstraat 5, 4815 NC Breda'))

    context = {
        'result':result,
    }
    return render(request, 'google/geocode.html', context)

def map(request):
    key = settings.GOOGLE_API_KEY
    context = {
        'key':key
    }
    return render(request, 'google/map.html', context)

def home(request):

    count_pending = 0
    if request.user.is_authenticated:
        if request.user.is_data_entry:
            url = MAIN_URL + "watersupplysubmittedbyuser/"+str(request.user.id)+"/"
            json_response = requests.get(url).json()
            if 'count' in json_response:
                count_pending= count_pending + int(json_response['count'])
        #print(json_response)
        if request.user.is_provincial_department_head:          
            province = request.user.provincial_department_head_province_id.id            
            url = MAIN_URL + "watersupplypendingprovincial/" + str(province) +"/"
            json_response = requests.get(url).json()
            if 'count' in json_response:
                count_pending= count_pending + int(json_response['count'])
        if request.user.is_data_verifier_1:
            url = MAIN_URL + "watersupplycountpendingapproval/2/"
            json_response = requests.get(url).json()
            if 'count' in json_response:
                count_pending= count_pending + int(json_response['count'])
        if request.user.is_data_verifier_2:
            url = MAIN_URL + "watersupplycountpendingapproval/5/"
            json_response = requests.get(url).json()
            if 'count' in json_response:
                count_pending= count_pending + int(json_response['count'])
        if request.user.is_head_department:
            url = MAIN_URL + "watersupplycountpendingapproval/7/"
            json_response = requests.get(url).json()
            if 'count' in json_response:
                count_pending= count_pending + int(json_response['count'])
    context = {
        'count_pending' : count_pending,
        'key' : settings.GOOGLE_API_KEY
    }
    return render(request, 'home.html', context)