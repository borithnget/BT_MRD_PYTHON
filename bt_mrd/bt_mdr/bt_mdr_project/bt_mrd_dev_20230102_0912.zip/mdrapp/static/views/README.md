This folder contains *Handlebars* template files that are used to render output demo files.

For more information about Handlebars and views and how to use them, please refer to documentation.

**layouts** contains layout files for dashboards and different layouts, etc

**pages** contains files for different pages and their partials

**data** contains sample data used in Ace's demo. For example the *navbar notifications*, dashboard's *Best Sellers* table data, etc

